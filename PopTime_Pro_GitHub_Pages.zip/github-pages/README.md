# Pop Time Pro — Gestão de Equipamentos e Efluentes

Aplicativo web de controle de ativos, etiquetas QR e estoque industrial.

## Abrir o app

Depois de publicar no GitHub Pages, acesse:

`https://SEU_USUARIO.github.io/NOME_DO_REPOSITORIO/`

Use **HTTPS** (obrigatório para a câmera do leitor QR no celular).

## Publicar no GitHub Pages (passo a passo)

### 1. Criar o repositório
1. Acesse [https://github.com/new](https://github.com/new)
2. Nome sugerido: `pop-time-pro`
3. Deixe **público**
4. **Não** marque "Add a README"
5. Clique em **Create repository**

### 2. Enviar os arquivos

No computador, na pasta deste projeto:

```bash
cd github-pages
git init
git add index.html .nojekyll README.md
git commit -m "Pop Time Pro - site estático"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/pop-time-pro.git
git push -u origin main
```

(Substitua `SEU_USUARIO` pelo seu usuário do GitHub.)

### 3. Ativar o GitHub Pages
1. No repositório: **Settings** → **Pages**
2. **Source**: Deploy from a branch
3. **Branch**: `main` / pasta `/ (root)`
4. Save
5. Aguarde 1–2 minutos e abra o link mostrado (ex.: `https://seu-usuario.github.io/pop-time-pro/`)

## Câmera no celular

- Abra sempre pelo link **https://…github.io…**
- Não abra o arquivo HTML baixado (`content://` ou `file://`) — a câmera fica bloqueada
- Na primeira vez, permita o acesso à **Câmera** quando o navegador pedir

## Recursos

- Controle de estoque / ativos
- Etiquetas com QR Code
- Leitor de QR (câmera traseira)
- Histórico e não conformidades
- Persistência local com SQLite (sql.js + IndexedDB) no navegador
